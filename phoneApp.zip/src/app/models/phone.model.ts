export class Phone {
    constructor(
        public id: string,
        public barnd: string,
        public manufacturer: string,
        public specification: string,
        public imgUrl: string,
        public price: number
    ) {}
}
